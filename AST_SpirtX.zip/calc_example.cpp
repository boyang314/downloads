// � Copyright John R. Bandela 2002. 

// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all
// copies. This software is provided "as is" without express or
// implied warranty, and with no claim as to its suitability for any
// purpose.

#include <iostream>
#include <boost/spirit/spirit_core.hpp>
#include "jrb_spirit_ast.hpp"
#include<map>
#include<cmath>
#include<iomanip>

// This is the symbol table
std::map<std::string,double> symbols;

// Declare the classes for parsing
struct JRBCalc :public spirit::ast::tree_node<JRBCalc>{
	double getValue(){
		double v = getVal();
		symbols["ans"] = v;
		return v;
	};
	virtual double getVal(){return 0.0;}
};

struct PlusOperator:public JRBCalc{
	double getVal(){
		return child(0)->getVal() + child(1)->getVal();
	}
};

struct MultOperator:public JRBCalc{
	double getVal(){
		return child(0)->getVal() * child(1)->getVal();
	}
};

struct DivOperator:public JRBCalc{
	double getVal(){
		return child(0)->getVal() / child(1)->getVal();
	}
};

struct MinusOperator:public JRBCalc{
	double getVal(){
		return child(0)->getVal() - child(1)->getVal();
	}
};

struct Num:public JRBCalc{
	double getVal(){
		return atof(value().c_str());
	}
};

struct ID:public JRBCalc{
	double getVal(){
		return symbols[value()];
	}
};

struct Assign:public JRBCalc{
	double getVal(){
		double v = child(1) -> getVal();
		symbols[child(0)->value()] = v;
		return v;

	}
};

struct Cosine:public JRBCalc{
	double getVal(){
		double v = child(0) -> getVal();
		return cos(v);;

	}
};
struct Sine:public JRBCalc{
	double getVal(){
		double v = child(0) -> getVal();
		return sin(v);;

	}
};
struct Tangent:public JRBCalc{
	double getVal(){
		double v = child(0) -> getVal();
		return tan(v);;

	}
};

struct Exp:public JRBCalc{
	double getVal(){
		double v = child(0) -> getVal();
		return exp(v);;

	}
};
struct Neg:public JRBCalc{
	double getVal(){
		return -child(0)->getVal();

	}
};
struct Pi:public JRBCalc{
	double getVal(){
		return std::asin(1.0)*2;
	}
};
struct Pow:public JRBCalc{
	double getVal(){
		return std::pow(child(0)->getVal(),child(1)->getVal());
	}
};
struct Log:public JRBCalc{
	double getVal(){
		return std::log(child(0)->getVal());
	}
};
struct List:public JRBCalc{
	struct outputter{
		template<class T>
			void operator()(T& t){
			std::cout << t.first << " = " << t.second << "\n";
		}
	};
	double getVal(){
		std::for_each(symbols.begin(),symbols.end(),outputter());
		return 0.0;
	}
};

struct calculator:public spirit::grammar<calculator>{
	template<class ScannerT>
	struct definition{
		typedef spirit::rule<ScannerT> rule_t;
		rule_t Expression,Number, Term, Y, Exp, Primary, X,Identifier,Start,Assignment;
		definition(){
			using namespace spirit;
			using namespace ast;
			Start = Assignment
				| Expression
				| strlit<>("?")										>"list";

			Assignment 	= Identifier >> '=' >> Expression	> "assign";

			Expression 	= Term >> Y	;

			Y	= ( '+' >> Term > build_tree("add",2) ) >> Y
				| ('-' >> Term > build_tree("sub",2) ) >> Y
				| epsilon_p;

			Term = Exp >> X;

			X 	= '*' >> Term										> build_tree("mult",2)
				| '/' >> Term										> build_tree("div",2)
				| epsilon_p;

			Exp = Primary >> '^' >> Primary			> "pow"
				| Primary;
			Primary 
				= strlit<>("cos") >> '(' >> Expression >> ')'			> "cos"
				| strlit<>("sin") >> '(' >> Expression >> ')'			> "sin"
				| strlit<>("tan") >> '(' >> Expression >> ')'			> "tan"
				| strlit<>("exp") >> '(' >> Expression >> ')'			> "exp"
				| strlit<>("log") >> '(' >> Expression >> ')'			> "log"
				| strlit<>("pi")										> "pi"
				| strlit<>("-") >> Primary							> "neg"
				| strlit<>("+") >> Primary
				| '(' >> Expression >> ')'
				| Number;

			Number	= ureal_p										> leaf("num")
					| Identifier;

			Identifier 	= lexeme_d[(alpha_p >> *(alpha_p|digit_p)) - strlit<>("pi")]						> leaf("id");
		}

		rule_t const&
			start() const { return Start;}
	};
};

void do_calc(const std::string& s){
	typedef spirit::ast::abstract_syntax_tree<std::string::const_iterator,JRBCalc> parse_tree_t;
	parse_tree_t p;
	calculator calc;
	p.add_node_type<DivOperator> ("div");
	p.add_node_type<MinusOperator> ("sub");
	p.add_node_type<MultOperator> ("mult");
	p.add_node_type<PlusOperator> ("add");
	p.add_node_type<Num> ("num");
	p.add_node_type<ID> ("id");
	p.add_node_type<Assign> ("assign");
	p.add_node_type<Cosine> ("cos");
	p.add_node_type<Sine> ("sin");
	p.add_node_type<Tangent> ("tan");
	p.add_node_type<Pi> ("pi");
	p.add_node_type<Pow> ("pow");
	p.add_node_type<Exp> ("exp");
	p.add_node_type<Log> ("log");
	p.add_node_type<Neg> ("neg");
	p.add_node_type<List>("list");

	p.set_sequence(s.begin(),s.end());

	if(p.parse(calc).full){
		std::cout << std::setprecision(16) << p.root()->getValue() << "\n";;
		std::cout << *p.root()<<"\n";;
	}
	else{
		std::cout << "syntax error\n";
	}
}

int main(){
	while(std::cin){
		std::string line;
		std::getline(std::cin,line);
		do_calc(line);
	}
}
