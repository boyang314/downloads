// � Copyright John R. Bandela 2002. 

// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all
// copies. This software is provided "as is" without express or
// implied warranty, and with no claim as to its suitability for any
// purpose.

#include <iostream>
#include <vector>
#include <algorithm>
#include<iterator>
#include <string>
#include <stack>
#include <numeric>
#include <memory>

#include "jrb_spirit_ast_container.hpp"


	namespace spirit{
		namespace ast{
			namespace detail{

struct auto_children{
template<class Iter1, class Iter2,class C>
   void operator()(Iter1 beg,Iter2,C* context,int depth, const std::string& s)const{

  int children = context->num(depth+1);

  typedef C context_type;
  typedef typename context_type::node_type TNode;
  std::auto_ptr<TNode> node(context->create_node(s));
  for(;children;--children){
    node->add_child(context->st_.back(),0);
    context->st_.pop_back();
  }
  context->st_.push_back(node.release());

   context->num(depth)++;
   context->num(depth+1) = 0;
}
};
struct numbered_children{
   int children;
   numbered_children(int c):children(c){}

template<class Iter1, class Iter2,class C>
   void operator()(Iter1 beg,Iter2,C* context,int depth, const std::string& s)const{

   int s2c = children - context->num(depth+1);
   context->num(depth)-=s2c;
   context->num(depth+1)+=s2c;
   typedef C context_type;
  typedef typename context_type::node_type TNode;
  std::auto_ptr<TNode> node(context->create_node(s));
  for(int ch = children;ch;--ch){
    node->add_child(context->st_.back(),0);
    context->st_.pop_back();
  }


  context->st_.push_back(node.release());


   context->num(depth)++;
   context->num(depth+1) = 0;
}
};

struct no_children{
template<class Iter1, class Iter2,class C>
   void operator()(Iter1 beg,Iter2 end,C* context,int depth, const std::string& s)const{

	std::string str;
	for(Iter1 temp = beg; temp != end;++temp){
		str+= *temp;
	}

	typedef C context_type;
  typedef typename context_type::node_type TNode;
  std::auto_ptr<TNode> node(context->create_node(s,str));

  context->st_.push_back(node.release());


   context->num(depth)++;
   context->num(depth+1) = 0;


}
};

template <typename ParserT, typename ActionT>
class tree_action
:   public spirit::unary<ParserT >,
    public spirit::parser<tree_action<ParserT, ActionT> > {

public:


    tree_action(ParserT const& parser, ActionT const& actor, const std::string& str)
    :  spirit::unary<ParserT >(parser),
	actor_(actor)
{
	std::size_t len = (str.size()<strsize-1?str.size():strsize-1);
	std::copy(str.begin(),str.begin() + len,str_);
	str_[len] = 0;
}


    template <typename ScannerT>
    spirit::match<>
    parse(ScannerT& scan) const
    {
		
    


		typename ScannerT::iterator_t
          begin = scan.first;

		typename ScannerT::context_type::st_type st2(scan.get_context()->st_);
    typename ScannerT::context_type::vec_type vec2(scan.get_context()->vec_);
     int mydepth = scan.get_context()->depth()++;


    spirit::match<> hit = this->subject().parse(scan);



   if (hit){

	   actor_(begin,scan.first,scan.get_context(),mydepth,str_);
   }
    else{
      scan.get_context()->st_.swap(st2);
      scan.get_context()->vec_.swap(vec2);
    }
    scan.get_context()->depth()--;
    return hit;
}

private:
	// Note this is a workaround because some compilers
	// do not like non-primitive member variables in parser objects
	// as per the SpiritX readme.
	enum{strsize = 128};
	char str_[strsize];
    ActionT  actor_;
};

}


struct build_tree{
  std::string name;
  int children;

  build_tree(std::string nm,int c)
  : name(nm),children(c){}
};

struct leaf{
  std::string name;
  explicit leaf(const std::string& nm)
  : name(nm){}
};







}
}

template<class T>
spirit::ast::detail::tree_action<T,spirit::ast::detail::auto_children > operator>(const spirit::parser<T>& p,  const std::string& s){
	return spirit::ast::detail::tree_action<T, spirit::ast::detail::auto_children>(p.derived(),spirit::ast::detail::auto_children(),s);
}

template<class T>
spirit::ast::detail::tree_action<T,spirit::ast::detail::numbered_children > operator >(const spirit::parser<T>& p, const spirit::ast::build_tree& b){
   return spirit::ast::detail::tree_action<T, spirit::ast::detail::numbered_children>(p.derived(),
   spirit::ast::detail::numbered_children(b.children),b.name);
}
template<class T>
spirit::ast::detail::tree_action<T,spirit::ast::detail::no_children > operator>(const spirit::parser<T>& p, const spirit::ast::leaf& r){
   return spirit::ast::detail::tree_action<T, spirit::ast::detail::no_children>(p.derived(),spirit::ast::detail::no_children(),r.name);
}