// � Copyright John R. Bandela 2002. 

// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all
// copies. This software is provided "as is" without express or
// implied warranty, and with no claim as to its suitability for any
// purpose.

#include "jrb_spirit_ast_tree.hpp"
#include <boost/spirit/spirit_core.hpp>
#include <cassert>
#include <boost/scoped_ptr.hpp>
#include <boost/function.hpp>
#include <boost/bind.hpp>
#include <map>

namespace spirit{
	namespace ast{ 
		namespace detail{

			template<class T>
			struct tree_context{

				typedef std::vector<int> vec_type;
				typedef std::vector<T*> st_type;
				typedef T node_type;




				vec_type vec_;
				st_type st_;
				int depth_;
				boost::function1<T*,const std::string&> node_maker_;

				tree_context():depth_(0){}

				T* create_node(const std::string& nodeName){
					return node_maker_(nodeName);
				}
				T* create_node(const std::string& nodeName,const std::string& value)
				{
					T* node = node_maker_(nodeName);
					node->value(value);
					return node;
				}
				int& depth(){return depth_;}
				int& num(unsigned int n){

					if( n >= vec_.size())
						vec_.resize(n+1,0);

					return vec_[n];
				}

				void reset(){std::for_each(st_.begin(),st_.end(),detail::deleter());}

				~tree_context(){
					reset();

				}




			};
			template<class C,class IterPolicy=spirit::iteration_policy>
			struct context_holder
				:public IterPolicy
			{
				typedef C context_type;
				mutable context_type* context_;

				context_holder(context_type* context):context_(context){}
				context_holder():context_(0){}
				context_type* get_context()const {
					assert(context_);return context_;}

			};
		}

		template<class T>
		struct default_node_creator{
			T* operator()(const std::string& s){
				std::auto_ptr<T> ptr(new T);
				ptr->name(s);
				return ptr.release();
			}
			std::string name_;
			default_node_creator(const std::string& s):name_(s){}
		};


		template<class T,class TNode =  default_tree_node, class C = detail::tree_context<TNode> >
		struct abstract_syntax_tree{

			typedef TNode node_type;

			T begin_;
			T end_;
			C context_;
			typedef boost::function1<TNode*,std::string> func_type;
			typedef std::map<std::string,func_type > map_type;
			map_type nmap_;
			func_type default_creator_;


			abstract_syntax_tree():begin_(),end_()
			{
				context_.node_maker_ = boost::bind(&abstract_syntax_tree::create_node,this,_1);
				default_creator_ = boost::bind(&abstract_syntax_tree::create_def_node,this,_1);
			}

			abstract_syntax_tree(T b ,T e):begin_(b),end_(e){
				context_.node_maker_ = boost::bind(&abstract_syntax_tree::create_node,this,_1);
				default_creator_ = boost::bind(&abstract_syntax_tree::create_def_node,this,_1);
			}


			void set_sequence(T b ,T e){
				begin_ = b;
				end_ = e;
				context_.reset();
			}


			TNode* root(){return context_.st_[0];}
			TNode* create_def_node(const std::string& nodeName){
				std::auto_ptr<TNode> ptr(new TNode);
				ptr->name(nodeName);
				return ptr.release();
			}

			TNode* create_node(const std::string& nodeName){
				map_type::iterator loc = nmap_.find(nodeName);
				if(loc==nmap_.end())
					return default_creator_(nodeName);
				else
					return (*loc).second(nodeName);
			}

			void reset_node_names(){
				nmap_.clear();
			}



			template<class NT>
				void add_node_type(const std::string& s){
					nmap_[s] = default_node_creator<NT>(s);
				}

				void add_node_type(const std::string& s, func_type f){
					nmap_[s] = f;
				}
				template<class NT>
					void add_node_type(const default_node_creator<NT>& c){
						nmap_[c.name_] = c;
					}



					template<class Grammar,class SkipT>
						spirit::parse_info<T>
						parse(
						Grammar const& , SkipT const& skip)
					{


						using namespace spirit;
						typedef skip_parser_iteration_policy<SkipT,detail::context_holder<C> >     iter_policy_t;
						typedef scanner_policies<iter_policy_t>         scanner_policies_t;
						typedef scanner<T, scanner_policies_t>  scanner_t;

						iter_policy_t iter_policy(skip);
						scanner_policies_t policies(iter_policy);
						policies.context_ = &context_;
						T first = begin_;
						scanner_t scan(first, end_, policies);
						typename Grammar::definition<scanner_t> g;
						match<nil_t> hit = g.start().parse(scan);
						return parse_info<T>(
							first, hit, hit && (first == end_), hit.length());

					}


					template<class Grammar>
						spirit::parse_info<T>
						parse(
						Grammar const& g){
							return parse(g,spirit::space_p);
						}


		};


		template<class T, class P>
			void add_node_type(P& p,const std::string& s){
				p.add_node_type(s,default_node_creator<T>(s));
			}



	}
}



