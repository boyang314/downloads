/*=============================================================================
    Composite parsers

    Spirit V1.2
    Copyright (c) 2001, Joel de Guzman

    This software is provided 'as-is', without any express or implied
    warranty. In no event will the copyright holder be held liable for
    any damages arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute
    it freely, subject to the following restrictions:

    1.  The origin of this software must not be misrepresented; you must
        not claim that you wrote the original software. If you use this
        software in a product, an acknowledgment in the product documentation
        would be appreciated but is not required.

    2.  Altered source versions must be plainly marked as such, and must
        not be misrepresented as being the original software.

    3.  This notice may not be removed or altered from any source
        distribution.

    Acknowledgements:

        Special thanks to Dan Nuffer, John (EBo) David, Chris Uzdavinis,
        and Doug Gregor. These people are most instrumental in steering
        Spirit in the right direction.

        Special thanks also to people who have contributed to the code base
        and sample code, ported Spirit to various platforms and compilers,
        gave suggestions, reported and provided bug fixes. Alexander
        Hirner, Andy Elvey, Bogdan Kushnir, Brett Calcott, Bruce Florman,
        Changzhe Han, Colin McPhail, Hakki Dogusan, Jan Bares, Joseph
        Smith, Martijn W. van der Lee, Raghavendra Satish, Remi Delcos, Tom
        Spilman, Vladimir Prus, W. Scott Dillman, David A. Greene, Bob
        Bailey, Hartmut Kaiser.

        Finally special thanks also to people who gave feedback and
        valuable comments, particularly members of Spirit's Source Forge
        mailing list and boost.org.

    URL: http://spirit.sourceforge.net/

=============================================================================*/
#ifndef SPIRIT_COMPOSITE_HPP
#define SPIRIT_COMPOSITE_HPP

///////////////////////////////////////////////////////////////////////////////

#include "boost/spirit/spirit_fwd.hpp"

///////////////////////////////////////////////////////////////////////////////
namespace spirit {

///////////////////////////////////////////////////////////////////////////////
//
//  embed_trait
//
//      Typically, parser objects are embedded by value. The special
//      case is the rule where a reference is stored instead. This
//      class and its specialization take care of that.
//
///////////////////////////////////////////////////////////////////////////////
template <typename T>
struct embed_trait
{
    typedef T type;
};

//////////////////////////////////
template <typename IteratorT>
struct embed_trait<rule<IteratorT> >
{
    typedef rule<IteratorT> const& type;
};

//////////////////////////////////
template <typename CharT, typename T, typename SetT>
struct embed_trait<symbols<CharT, T, SetT> >
{
    typedef symbols<CharT, T, SetT> const& type;
};

///////////////////////////////////////////////////////////////////////////////
//
//  unary class.
//
//      Class composed of a single subject.
//
///////////////////////////////////////////////////////////////////////////////
template <typename S>
struct unary {
                    unary()                 : subj() {}
                    unary(S const& subj_)   : subj(subj_) {}
    S&              subject()               { return subj; }
    S const&        subject() const         { return subj; }

private:

    typename embed_trait<S>::type    subj;
};

///////////////////////////////////////////////////////////////////////////////
//
//  binary class.
//
//      Class composed of a pair.
//
///////////////////////////////////////////////////////////////////////////////
template <typename A, typename B>
struct binary {
                    binary() {}
                    binary(A const& a_, B const& b_)
                    : a(a_), b(b_) {}

    A&              left()          { return a; }
    A const&        left() const    { return a; }
    B&              right()         { return b; }
    B const&        right() const   { return b; }

private:

    typename embed_trait<A>::type    a;
    typename embed_trait<B>::type    b;
};

///////////////////////////////////////////////////////////////////////////////
}   //  namespace Spirit

#endif
