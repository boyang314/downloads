#include <iostream>
#include <string>
#include "boost/spirit/spirit.hpp"

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////

namespace {

    void    doInt(char const* str, char const* end)
    {
        string  s(str, end);
        cout << s << endl;
    }

    void    doAdd(char const*, char const*)     { cout << "ADD\n"; }
    void    doSubt(char const*, char const*)    { cout << "SUBT\n"; }
    void    doMult(char const*, char const*)    { cout << "MULT\n"; }
    void    doDiv(char const*, char const*)     { cout << "DIV\n"; }
}

/////////////////////////////////////////////////////////////////////////////////////////
static void
parse(rule<> const& r, char const* expr)
{
    cout << "/////////////////////////////////////////////////////////\n\n";

    parse_info<char const*>
        result = parse(expr, r, space);

    if (result.full)
    {
        cout << "\t\t" << expr << "\tParses OK\n";
    }
    else
    {
        cout << "\t\t" << expr << "\tFails parsing\n";
        cout << "\t\t";
        for (int i = 0; i < (result.stop - expr); i++)
            cout << " ";
        cout << "^--Here\n\n\n";
    }
}

/////////////////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tCalculator grammar...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    //  Start grammar definition

    rule<>  expr;
    rule<>  integer = lexeme[ (!(ch_p('+') | '-') >> +digit)[&doInt] ];
    rule<>  group   = '(' >> expr >> ')';
    rule<>  expr1   = integer | group;
    rule<>  expr2   = expr1 >> *(('*' >> expr1)[&doMult] | ('/' >> expr1)[&doDiv]);
    expr            = expr2 >> *(('+' >> expr2)[&doAdd] | ('-' >> expr2)[&doSubt]);

    //  End grammar definition

    cout << "=================================================\n";
    cout << "The following expressions should fail to parse...\n";
    cout << "=================================================\n\n";
    parse(expr, "- ");
    parse(expr, "1 2 3 4 5");
    parse(expr, "- 1234");
    parse(expr, "1 ++ 1");
    parse(expr, "1 ^ 1");
    parse(expr, "(1 + 1) * 3)");
    parse(expr, "(1 + 1) * 3 4");
    parse(expr, "(1 + (2 + (3 + (4 + 5)))");
    parse(expr, ")1 + 1)");

    cout << "=================================================\n";
    cout << "The following expressions should parse OK...\n";
    cout << "=================================================\n\n";
    parse(expr, "12345");
    parse(expr, "-12345");
    parse(expr, "+12345");
    parse(expr, "1 + 2");
    parse(expr, "1 * 2");
    parse(expr, "1/2 + 3/4");
    parse(expr, "1 + 2 + 3 + 4");
    parse(expr, "1 * 2 * 3 * 4");
    parse(expr, "(1 + 2) * (3 + 4)");
    parse(expr, "(-1 + 2) * (3 + -4)");
    parse(expr, "1 + ((6 * 200) - 20) / 6");
    parse(expr, "(1 + (2 + (3 + (4 + 5))))");

    return 0;
}


