#include <iostream>
#include <vector>
#include <cstdlib>
#include "boost/spirit/spirit.hpp"

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////
//
//  The VMachine
//
/////////////////////////////////////////////////////////////////////////////////////////
enum ByteCodes {

    OP_ADD,     //  add top two stack entries
    OP_SUB,     //  subtract top two stack entries
    OP_MUL,     //  multiply top two stack entries
    OP_DIV,     //  divide top two stack entries
    OP_INT,     //  push constant integer into the stack
    OP_RET      //  return from the interpreter
};

/////////////////////////////////////////////////////////////////////////////////////////
class vmachine {

public:
                vmachine(unsigned stackSize = 1024)
                :   stack(new int[stackSize]),
                    stackPtr(stack) {}
                ~vmachine() { delete [] stack; }
    int         top() const { return stackPtr[-1]; };
    void        execute(unsigned code[]);

private:

    int*        stack;
    int*        stackPtr;
};

/////////////////////////////////////////////////////////////////////////////////////////
void
vmachine::execute(unsigned code[])
{
    unsigned const* pc = code;
    bool            running = true;

    while (running) {

        switch (*pc++) {

            case OP_ADD:
                stackPtr--;
                stackPtr[-1] += stackPtr[0];
                break;

            case OP_SUB:
                stackPtr--;
                stackPtr[-1] -= stackPtr[0];
                break;

            case OP_MUL:
                stackPtr--;
                stackPtr[-1] *= stackPtr[0];
                break;

            case OP_DIV:
                stackPtr--;
                stackPtr[-1] /= stackPtr[0];
                break;

            case OP_INT:
                //  Check stack overflow here
                *stackPtr++ = *pc++;
                break;

            case OP_RET:
                running = false;
                break;
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////
//
//  The Compiler
//
/////////////////////////////////////////////////////////////////////////////////////////
vector<unsigned>    code;

/////////////////////////////////////////////////////////////////////////////////////////
struct push_int {

    void operator()(char const* str, char const* /*end*/) const
    {

        unsigned    n = std::strtol(str, 0, 10);
        code.push_back(OP_INT);
        code.push_back(n);
        cout << "push\t" << int(n) << endl;
    }

};

/////////////////////////////////////////////////////////////////////////////////////////
struct push_op {

    push_op(unsigned op_)
    : op(op_) {}

    void operator()(char const*, char const*) const
    {
        code.push_back(op);

        switch (op) {

            case OP_ADD:
                cout << "add\n";
                break;

            case OP_SUB:
                cout << "sub\n";
                break;

            case OP_MUL:
                cout << "mul\n";
                break;

            case OP_DIV:
                cout << "div\n";
                break;
        }
    }

    unsigned op;
};

/////////////////////////////////////////////////////////////////////////////////////////
static bool
compile(rule<> const& r, char const* expr)
{
    cout << "\n/////////////////////////////////////////////////////////\n\n";

    parse_info<char const*>
        result = parse(expr, r, space);

    if (result.full)
    {
        cout << "\t\t" << expr << " Parses OK\n\n\n";
        code.push_back(OP_RET);
        return true;
    }
    else
    {
        cout << "\t\t" << expr << " Fails parsing\n";
        cout << "\t\t";
        for (int i = 0; i < (result.stop - expr); i++)
            cout << " ";
        cout << "^--Here\n\n\n";
        return false;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tA simple virtual machine...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "Type an expression...or [q or Q] to quit\n\n";

    //  Start grammar definition

    rule<>  expr, integer, group, expr1, expr2;

    integer =   lexeme[ (!(ch_p('+') | '-') >> +digit)[push_int()] ];
    group   =   '(' >> expr >> ')';
    expr1   =   integer | group;
    expr2   =   expr1 >>
            *(  ('*' >> expr1)[push_op(OP_MUL)]
            |   ('/' >> expr1)[push_op(OP_DIV)]
            );
    expr    = expr2 >>
            *(  ('+' >> expr2)[push_op(OP_ADD)]
            |   ('-' >> expr2)[push_op(OP_SUB)]);

    //  End grammar definition

    vmachine    mach;
    while (true)
    {
        char str[256];
        code.clear();
        cin.getline(str, 256);
        if (str[0] == 'q' || str[0] == 'Q')
            break;

        if (compile(expr, &str[0]))
        {
            mach.execute(&code[0]);
            cout << "result = " << mach.top() << "\n\n";
        }
    }

    cout << "Bye... :-) \n\n";

    return 0;
}


