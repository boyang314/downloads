#include "boost/spirit/spirit.hpp"
#include <iostream>
#include <stack>
#include <functional>

////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

////////////////////////////////////////////////////////////////////////////
stack<double> evaluation_stack;
double* np = 0;

////////////////////////////////////////////////////////////////////////////
struct push_num {

    typedef double arg_type; //  Required

    void operator()(double n) const
    {
        evaluation_stack.push(n);
        cout << "push\t" << n << endl;
    }
};

////////////////////////////////////////////////////////////////////////////
template <class op>
struct do_op
{
    do_op(op const& theOp) : m_op(theOp) {}
    op m_op;

    void operator()(char const*, char const*) const
    {
        double rhs = evaluation_stack.top();
        evaluation_stack.pop();
        double lhs = evaluation_stack.top();
        evaluation_stack.pop();

        cout << "popped " << lhs << " and " << rhs << " from the stack. ";
        cout << "pushing " << m_op(lhs, rhs) << " onto the stack.\n";
        evaluation_stack.push(m_op(lhs, rhs));
    }
};

////////////////////////////////////////////////////////////////////////////
template <class op>
do_op<op>
make_op(op const& theOp)
{
    return do_op<op>(theOp);
}

////////////////////////////////////////////////////////////////////////////
struct do_negate
{
    void operator()(char const*, char const*) const
    {
        double lhs = evaluation_stack.top();
        evaluation_stack.pop();

        cout << "popped " << lhs << " from the stack. ";
        cout << "pushing " << -lhs << " onto the stack.\n";
        evaluation_stack.push(-lhs);
    }
};

////////////////////////////////////////////////////////////////////////////
struct get_var
{
    void operator()(char const* first, char const* last, double n) const
    {
        evaluation_stack.push(n);
        string ident(first, last);
        cout << "push\t" << ident << " = " << n << endl;
    }
};

////////////////////////////////////////////////////////////////////////////
struct set_var
{
    void operator()(char const* /*first*/, char const* /*last*/, double& n) const
    {
        np = &n;
    }
};

////////////////////////////////////////////////////////////////////////////
struct redecl_var
{
    void operator()(char const* /*first*/, char const* /*last*/, double& /*n*/) const
    {
        cout << "Warning. You are attempting to re-declare a var.\n";
    }
};

////////////////////////////////////////////////////////////////////////////
struct do_assign
{
    void operator()(char const*, char const*) const
    {
        if (np)
        {
            *np = evaluation_stack.top();
            cout << "assigning\n";
        }
    }
};

////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tThe calculator with variables...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "Type a statement...or [q or Q] to quit\n\n";
    cout << "Variables may be declared:\t\tExample: var i, j, k\n";
    cout << "Assigning to a variable:\t\tExample: i = 10 * j\n";
    cout << "To evaluate an expression:\t\tExample: ? i * 3.33E-3\n\n";

    //  Start grammar definition

    rule<> statement, declaration, var_decl, assignment, expression, term, factor;
    symbols<double> vars;

    factor      =   real_p[push_num()]
                |   vars[get_var()]
                |   '(' >> expression >> ')'
                |   ('-' >> factor)[do_negate()];
    term        =   factor >>
                *(  ('*' >> factor)[make_op(multiplies<double>())]
                |   ('/' >> factor)[make_op(divides<double>())]
                );
    expression  =   term >>
                *(  ('+' >> term)[make_op(plus<double>())]
                |   ('-' >> term)[make_op(minus<double>())]
                );
    assignment  = vars[set_var()] >> '=' >> expression[do_assign()];
    var_decl    = lexeme[((alpha >> *(alnum | '_')) - vars[redecl_var()])[vars.add]];
    declaration = "var" >> var_decl >> *(',' >> var_decl);
    statement   = declaration | assignment | '?' >> expression;

    //  End grammar definition

    while (true)
    {
        char str[256];
        cin.getline(str, 256);
        if (str[0] == 'q' || str[0] == 'Q')
            break;
        np = 0;

        if (parse(str, statement, space).full)
        {
            cout << "parsing succeeded\n";
            if (!evaluation_stack.empty())
            {
                cout << "result = " << evaluation_stack.top() << "\n\n";
                evaluation_stack.pop();
            }
            else
            {
                cout << endl;
            }
        }
        else
        {
            cout << "parsing failed\n\n";
        }
    }

    cout << "Bye... :-) \n\n";
    return 0;
}


