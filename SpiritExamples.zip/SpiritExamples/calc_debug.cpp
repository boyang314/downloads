#define SPIRIT_DEBUG  ///$$$ DEFINE THIS WHEN DEBUGGING $$$///

#include "boost/spirit/spirit.hpp"
#include <iostream>
#include <stack>
#include <functional>

////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

////////////////////////////////////////////////////////////////////////////
stack<long> evaluation_stack;

////////////////////////////////////////////////////////////////////////////
struct push_int {

    void operator()(char const* str, char const* /*end*/) const
    {
        long n = strtol(str, 0, 10);
        evaluation_stack.push(n);
        cout << "push\t" << long(n) << endl;
    }
};

////////////////////////////////////////////////////////////////////////////
template <class op>
struct do_op
{
    do_op(op const& theOp) : m_op(theOp) {}
    op m_op;

    void operator()(char const*, char const*) const
    {
        long rhs = evaluation_stack.top();
        evaluation_stack.pop();
        long lhs = evaluation_stack.top();
        evaluation_stack.pop();

        cout << "popped " << lhs << " and " << rhs << " from the stack. ";
        cout << "pushing " << m_op(lhs, rhs) << " onto the stack.\n";
        evaluation_stack.push(m_op(lhs, rhs));
    }
};

////////////////////////////////////////////////////////////////////////////
template <class op>
do_op<op>
make_op(op const& theOp)
{
    return do_op<op>(theOp);
}

////////////////////////////////////////////////////////////////////////////
struct do_negate
{
    void operator()(char const*, char const*) const
    {
        long lhs = evaluation_stack.top();
        evaluation_stack.pop();

        cout << "popped " << lhs << " from the stack. ";
        cout << "pushing " << -lhs << " onto the stack.\n";
        evaluation_stack.push(-lhs);
    }
};

////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tThe simplest working calculator...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "Type an expression...or [q or Q] to quit\n\n";

    //  Start grammar definition

    rule<> expression, term, factor, integer;

    integer     =   lexeme[ (!ch_p('-') >> +digit)[push_int()] ];
    factor      =   integer
                |   '(' >> expression >> ')'
                |   ('-' >> factor)[do_negate()];
    term        =   factor >>
                *(  ('*' >> factor)[make_op(multiplies<long>())]
                |   ('/' >> factor)[make_op(divides<long>())]
                );
    expression  =   term >>
                *(  ('+' >> term)[make_op(plus<long>())]
                |   ('-' >> term)[make_op(minus<long>())]
                );

    SPIRIT_DEBUG_RULE(integer);
    SPIRIT_DEBUG_RULE(factor);
    SPIRIT_DEBUG_RULE(term);
    SPIRIT_DEBUG_RULE(expression);

    //  End grammar definition

    while (true)
    {
        char str[256];
        cin.getline(str, 256);
        if (str[0] == 'q' || str[0] == 'Q')
            break;

        if (parse(str, expression, space).full)
        {
            cout << "parsing succeeded\n";
            cout << "result = " << evaluation_stack.top() << "\n\n";
            evaluation_stack.pop();
        }
        else
        {
            cout << "parsing failed\n";
        }
    }

    cout << "Bye... :-) \n\n";
    return 0;
}


