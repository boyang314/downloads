#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
struct ftor {

    void
    operator () (char n) const { cout << n; }
};

void
foo(char n) { cout << n; }

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tCharacter actions...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const* str = "abcdefghijklmnop";
    char const* end(str + strlen(str));
    char const* str1(str);
    char const* str2(str);
    char const* str3(str);

    (+(anychar[&foo] - '\0')).parse(str1, end);     cout << endl;
    (+(anychar[ftor()] - '\0')).parse(str2, end);   cout << endl;

    char c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c;
    anychar[ref(c)].parse(str3, end);   cout << c << endl;

    return 0;
}

