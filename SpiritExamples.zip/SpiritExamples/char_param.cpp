#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tCharacter parser parameters...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const* str = "abbbbbbbbba";
    char c;

    bool    r = (anychar[ref(c)] >> *ch_p('b') >> ch_p(ref(c)))
        .parse(str, str + strlen(str));

    cout << (r ? "OK" : "OOOPS") << endl;

    return 0;
}

