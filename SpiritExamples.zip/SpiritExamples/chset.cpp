
#include "boost/spirit/spirit.hpp"
#include <iostream>

using namespace spirit;

static void
DrawRuler(char const* str)
{
    std::cout << std::endl << std::endl;
    std::cout << "\t_____________________________________________________________\n";
    std::cout << "\t" << str << std::endl;
    std::cout << "\t";
    for (char i = '!'; i < '^'; i++)
        std::cout << i;
    std::cout << "\n";
    std::cout << "\t_____________________________________________________________\n\n";
}

template <typename CharT>
static void
Draw(chset<CharT> a, char const* str)
{
    std::cout << "\t";

    for (int i = '!'; i < '^'; i++)
        if (a.test(i))
            std::cout << '*';
        else
            std::cout << " ";

    std::cout << "\t" << str << std::endl;
}

int
main()
{
    std::cout << "/////////////////////////////////////////////////////////\n\n";
    std::cout << "\t\tCharacter sets...\n\n";
    std::cout << "/////////////////////////////////////////////////////////\n\n";

    chset<>  a("0-9A-Z");
    range<>  b_('5', 'J');
    chset<>  b(b_);

    DrawRuler("Initial");
    Draw(a, "a \tchset<>  a(\"0-9A-Z\");");
    Draw(b, "b_ \trange<>  b_('5', 'J');");
    Draw(b, "b \tchset<>  b(b_);");

    DrawRuler("Inverse");
    Draw(~a, "~a");
    Draw(~~a, "~~a");
    Draw(~b, "~b");
    Draw(~b_, "~b_");

    DrawRuler("Union");
    Draw(a, "a");
    Draw(b, "b");
    Draw(a | b, "a | b");
    Draw(a | b_, "a | b_");
    Draw(b_ | a, "b_ | a");
    Draw(a | anychar, "a | anychar");
    Draw(b | anychar, "b | anychar");

    DrawRuler("Intersection");
    Draw(a, "a");
    Draw(b, "b");
    Draw(a & b, "a & b");
    Draw(a & b_, "a & b_");
    Draw(b_ & a, "b_ & a");
    Draw(a & anychar, "a & anychar");
    Draw(b & anychar, "b & anychar");

    DrawRuler("Difference");
    Draw(a, "a");
    Draw(b, "b");
    Draw(a - b, "a - b");
    Draw(b - a, "b - a");
    Draw(a - b_, "a - b_");
    Draw(b_ - a, "b_ - a");
    Draw(a - anychar, "a - anychar");
    Draw(anychar - a, "anychar - a");
    Draw(b - anychar, "b - anychar");
    Draw(anychar - b, "anychar - b");

    DrawRuler("Xor");
    Draw(a, "a");
    Draw(b, "b");
    Draw(a ^ b, "a ^ b");
    Draw(a ^ b_, "a ^ b_");
    Draw(b_ ^ a, "b_ ^ a");
    Draw(a ^ nothing, "a ^ nothing");
    Draw(a ^ anychar, "a ^ anychar");
    Draw(b ^ nothing, "b ^ nothing");
    Draw(b ^ anychar, "b ^ anychar");

    //  Converting from a chset with different CharT
    DrawRuler("Conversion");
    chset<wchar_t>  aw(range<wchar_t>('A','Z'));
    a = aw;
    Draw(aw, "chset<wchar_t> aw(range<wchar_t>('A','Z'))");
    Draw(a, "a = aw");

    return 0;
}
