#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
match
handler(char const* /*first*/, char const* /*last*/, char const* /*where*/, int /*what*/)
{
    cout << "exception caught..." << endl;
    return match();
}

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tExceptions...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const* str = "abcx";
    char const* first(str);
    char const* last(str + strlen(str));

    assertion<int>  expect(0);
    guard<int>      my_guard;

    my_guard(

        ch_p('a') >> 'b' >> 'c' >> expect(ch_p('d')),

    &handler).parse(first, last);

    return 0;
}

