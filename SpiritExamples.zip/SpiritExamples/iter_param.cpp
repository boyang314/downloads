#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tParser iterator parameters...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const  str[10] = { 8, 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 0 };
    char const* scan(str);
    char const* end(str + strlen(str));
    char c;

    bool    r = (anychar[ref(c)] >> ch_p('a').repeat(ref(c))).parse(scan, end);

    cout << int(c) << endl;

    cout << (r ? "OK" : "OOOPS") << endl;
    cout << scan << endl;

    return 0;
}

