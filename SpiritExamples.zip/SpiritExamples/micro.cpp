#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tMicro parser Test For Spirit...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    cout << "Give me a complex number of the form r or (r) or (r,i) \n";
    cout << "Type [q or Q] to quit\n\n";


    double  r = 0;
    double  i = 0;
    rule<>  rule    =   real_p[ref(r)]
                    |   '(' >> real_p[ref(r)] >> !(',' >> real_p[ref(i)]) >> ')';

    while (true)
    {
        char str[256];
        cin.getline(str, 256);
        if (str[0] == 'q' || str[0] == 'Q')
            break;

        r = 0;
        i = 0;

        if (parse(str, rule, space).full)
        {
            cout << endl;
            cout << "\t\t" << str << " parses OK\n";
            cout << "r = " << r << "\n";
            cout << "i = " << i << "\n\n";
        }
        else
        {
            cout << "parsing failed\n";
        }
    }

    cout << "Bye... :-) \n\n";

    return 0;
}


