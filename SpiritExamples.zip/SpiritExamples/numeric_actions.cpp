#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
struct ftor {

    typedef float arg_type; //  Required

    void
    operator () (float const& n) const { cout << n << endl; }
};

void
foo(float n) { cout << n << endl; }


///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tNumeric actions...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const* str = "123456.789E6";
    char const* end = str + strlen(str);

    char const* scan1(str);
    real_p[&foo].parse(scan1, end);

    char const* scan2(str);
    real_p[ftor()].parse(scan2, end);

    float n;
    char const* scan3(str);
    real_p[ref(n)].parse(scan3, end);
    cout << n << endl;

    return 0;
}
