#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tString extraction...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    char const* str = "abcdefghijklmnop";
    char const* scan(str);
    char const* end(str + strlen(str));
    string      s;

    (+anychar)[ref(s)].parse(scan, end);

    cout << s << endl;

    return 0;
}

