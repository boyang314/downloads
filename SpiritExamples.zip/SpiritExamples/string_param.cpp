#include <boost/spirit/spirit.hpp>
#include <iostream>

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tString parameters...\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    string      s;
    bool        r;
    rule<>      rule = (+alpha)[ref(s)] >> *str_p(ref(s));

    char const* str1 = "hello hello hello hello hello hello hello";
    char const* str2 = "world world world world world world";

    r = parse(str1, rule, space).full;
    cout << (r ? "OK" : "OOOPS") << endl;
    cout << str1 << endl;

    r = parse(str2, rule, space).full;
    cout << (r ? "OK" : "OOOPS") << endl;
    cout << str2 << endl;

    return 0;
}

