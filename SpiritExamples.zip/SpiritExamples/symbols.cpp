
#include <iostream>
#include <string>
#include "boost/spirit/spirit.hpp"

///////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace spirit;

///////////////////////////////////////////////////////////////////////////////
void
add(symbols<>& sym, char const* str)
{
    sym.add(str, str + strlen(str));
}

void
check(symbols<> const& sym, char const* str)
{
    char const* s = str;
    symbol_match<>  m = sym.parse(str, str + strlen(str));
    if (m)
        cout << s << " OK [non-matching=\"" << str << "\", matching-length=" << m.length() << "]" << endl;
    else
        cout << s << " is not a member [non-matching=\"" << str << "\", matching-length=" << m.length() << "]" << endl;
}

void
action1(char const* first, char const* last, int& data)
{
    string  str(first, last);
    cout << "got: " << str << endl;
    cout << "storing 123456 into data slot of " << str << endl;
    data = 123456;
}

void
action2(char const* first, char const* last, int data)
{
    string  str(first, last);
    cout << "got: " << str << endl;
    cout << "got: " << data << " from data slot of " << str << endl;
}

int
main()
{
    cout << "/////////////////////////////////////////////////////////\n\n";
    cout << "\t\tSymbol table test\n\n";
    cout << "/////////////////////////////////////////////////////////\n\n";

    symbols<>   sym;
    sym = "pineapple", "orange", "banana", "apple", "applepie";

    cout << "\nsym = \"pineapple\", \"orange\", \"banana\", \"apple\", \"applepie\";\n\n";

    check(sym, "pineapple");
    check(sym, "orange");
    check(sym, "banana");
    check(sym, "apple");
    check(sym, "pizza");
    check(sym, "steak");
    check(sym, "applepie");
    check(sym, "bananarama");
    check(sym, "applet");

    symbols<>   sym2 = sym;

    cout << "\nsym2 = sym\n\n";

    check(sym2, "pineapple");
    check(sym2, "orange");
    check(sym2, "banana");
    check(sym2, "apple");
    check(sym2, "pizza");
    check(sym2, "steak");
    check(sym2, "applepie");
    check(sym2, "bananarama");
    check(sym2, "applet");

    cout << "\nchecking data slot \"orange\" of sym\n";
    parse("orange", sym[&action1]);
    parse("orange", sym[&action2]);
    check(sym, "orange");

    return 0;
}
