#include "calculator.h"
#include "calculator_impl.h"

struct priv_data
{
    priv_data() : calc(eval) {};
    stack<operand_t>   eval;
    calculator      calc;
};

CCalculator::CCalculator()
{
  p_priv = new priv_data;
}

CCalculator::~CCalculator()
{
  delete (priv_data *) p_priv;
}


std::string CCalculator::eval(const std::string & str)
{
  priv_data & data(*(priv_data *)p_priv);

  parse_info<> info = parse(str.c_str(), data.calc, space_p);

  if (info.full)
  {
//    cout << "-------------------------\n";
//    cout << "Parsing succeeded\n";
//    cout << "-------------------------\n";
//    cout << "CalcResult: " << data.eval.top() << std::endl;
    return data.eval.top().getString();
  }
  else
  {
    cerr << "-------------------------\n";
    cerr << "Parsing failed\n";
    cerr << "stopped at: \": " << info.stop << "\"\n";
    cerr << "-------------------------\n";
    return "_ERROR: Parsing stopped at: \""+std::string(info.stop)+"\"";
  }

}
