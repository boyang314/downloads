#ifndef _CALCULATOR_H_
#define _CALCULATOR_H_

#include <string>
#include <map>

class CCalculator
{
  private:
    void * p_priv;
  public:
    CCalculator();
    ~CCalculator();
    std::string eval(const std::string & expr);
};

#endif
