/*=============================================================================
    Spirit v1.6.0
    Copyright (c) 2001-2003 Dan Nuffer
    Copyright (c) 2001-2003 Joel de Guzman
    http://spirit.sourceforge.net/

    Permission to copy, use, modify, sell and distribute this software is
    granted provided this copyright notice appears in all copies. This
    software is provided "as is" without express or implied warranty, and
    with no claim as to its suitability for any purpose.
=============================================================================*/
#include <boost/spirit/core.hpp>
#include <boost/spirit/symbols/symbols.hpp>
#include <boost/spirit/utility.hpp>
#include <iostream>
#include <stack>
#include <functional>
#include <string>

#include "stringnumber.h"
#include "escaped_string.h"

using namespace std;
using namespace boost::spirit;

typedef stringnumber operand_t;

struct push_num
{
    push_num(stack<operand_t>& eval_)
    : eval(eval_) {}

    void operator()(operand_t n) const
    {
        eval.push(n);
    }
    void operator() (const char *const &begin, const char *const &end) const
    {
        escaped_string es;
        es.set_escaped_str(std::string(begin, end));
        eval.push(std::string(es));
    }
    stack<operand_t>& eval;
};

template <typename op>
struct do_op
{
    do_op(op const& the_op, stack<operand_t>& eval_)
    : m_op(the_op), eval(eval_) {}

    void operator()(char const*, char const*) const
    {
        operand_t rhs = eval.top();
        eval.pop();
        operand_t lhs = eval.top();
        eval.pop();
        eval.push(m_op(lhs, rhs));
    }

    op m_op;
    stack<operand_t>& eval;
};

template <class op>
do_op<op>
make_op(op const& the_op, stack<operand_t>& eval)
{
    return do_op<op>(the_op, eval);
}

struct do_negate
{
    do_negate(stack<operand_t>& eval_)
    : eval(eval_) {}

    void operator()(char const*, char const*) const
    {
        operand_t lhs = eval.top();
        eval.pop();
        eval.push(-lhs);
    }

    stack<operand_t>& eval;
};

struct do_invert
{
    do_invert(stack<operand_t>& eval_)
    : eval(eval_) {}

    void operator()(char const*, char const*) const
    {
        operand_t lhs = eval.top();
        eval.pop();
        eval.push(!lhs);
    }

    stack<operand_t>& eval;
};

struct get_var
{
    get_var(stack<operand_t>& eval_)
    : eval(eval_) {}

    void operator()(operand_t n) const
    {
        eval.push(n);
    }

    stack<operand_t>& eval;
};

struct set_var
{
    set_var(operand_t*& var_)
    : var(var_) {}

    void operator()(operand_t& n) const
    {
        var = &n;
    }

    operand_t*& var;
};

struct do_assign
{
    do_assign(operand_t*& var_, stack<operand_t>& eval_)
    : var(var_), eval(eval_) {}

    void operator()(char const*, char const*) const
    {
        if (var != 0)
        {
            *var = eval.top();
        }
    }

    operand_t*& var;
    stack<operand_t>&  eval;
};

///////////////////////////////////////////////////////////////////////////////
//
//  Our calculator grammar
//
///////////////////////////////////////////////////////////////////////////////
struct calculator : public grammar<calculator>
{
    calculator(stack<operand_t>& eval_)
    : eval(eval_) {}

    template <typename ScannerT>
    struct definition
    {
        definition(calculator const& self)
        {
            factor =
                    confix_p('"', *c_escape_ch_p, '"')[push_num(self.eval)]
                |   real_p[push_num(self.eval)]
                |   vars[get_var(self.eval)]
                |   '(' >> or_expr >> ')'
                |   ('-' >> factor)[do_negate(self.eval)]
                |   ('!' >> factor)[do_invert(self.eval)]
                ;

            term =
                factor
                >> *(   ('*' >> factor)[make_op(multiplies<operand_t>(), self.eval)]
                    |   ('/' >> factor)[make_op(divides<operand_t>(), self.eval)]
                    )
                    ;

            expression =
                term
                >> *(  ('+' >> term)[make_op(plus<operand_t>(), self.eval)]
                    |   ('-' >> term)[make_op(minus<operand_t>(), self.eval)]
                    )
                    ;

            relation =
                expression
                >> *(  (">=" >> expression)[make_op(greater_equal<operand_t>(), self.eval)]
                    |   ('>' >> expression)[make_op(greater<operand_t>(), self.eval)]
                    |   ('<' >> expression)[make_op(less<operand_t>(), self.eval)]
                    |   ("<=" >> expression)[make_op(less_equal<operand_t>(), self.eval)]
                    )
                    ;

            equation =
                relation
                >> *(  ("==" >> relation)[make_op(equal_to<operand_t>(), self.eval)]
                    |   ("!=" >> relation)[make_op(not_equal_to<operand_t>(), self.eval)]
                    )
                    ;

            and_expr =
                equation
                >> *(  ('&' >> equation)[make_op(logical_and<operand_t>(), self.eval)]
                    )
                    ;

            or_expr =
                and_expr
                >> *(  ('|' >> and_expr)[make_op(logical_or<operand_t>(), self.eval)]
                    )
                    ;

            assignment =
                ( vars[set_var(self.var)]
                | ((alpha_p >> *(alnum_p | '_'))[vars.add] >> nothing_p) // will match never, but declares var
                | vars[set_var(self.var)] // get the fresh declared var
                )
                >> '=' >> or_expr[do_assign(self.var, self.eval)]
                ;

            statement =
                "set" >> assignment | or_expr
                ;
        }

        symbols<operand_t>  vars;
        rule<ScannerT>      statement, declaration, var_decl,
                            assignment, expression, term, factor,
                            relation, equation, and_expr, or_expr;

        rule<ScannerT> const&
        start() const { return statement; }
    };

    mutable operand_t* var;
    stack<operand_t>&  eval;
};

