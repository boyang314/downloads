#include "escaped_string.h"
#include <sstream>

std::string escaped_string::get_escaped_str() const
{
  std::ostringstream os;
  os << "\"";
  for (unsigned int i=0; i<str.size(); ++i)
  {
    switch (str[i])
    {
      case '"': os << "\\\""; break;
      case '\n': os << "\\\n"; break;
      case '\\': os << "\\\\"; break;
      default: os << str[i];
    }
  }
  os << "\"";
  return os.str();
}


std::ostream & escaped_string::outstream (std::ostream& ostr) const
{
  return ostr << get_escaped_str();
}


void escaped_string::set_escaped_str(const std::string & val)
{
  std::istringstream is(val.c_str());
  instream(is);
}


std::istream & escaped_string::instream (std::istream& istr)
{
  bool escaped = false;
  char c;

  str.erase();

  if ((istr.get(c)) && (c=='\"'))
  {
    while (istr.get(c))
    {
      if (escaped)
      {
        switch (c)
        {
          case '"': str+=c; break;
          case 'n': str+='\n'; break;
          case '\\': str+=c; break;
          default: str+='\\'; str+=c;
        }
        escaped=false;
      }
      else
      {
        switch (c)
        {
          case '\\': escaped=true; break;
          case '"':  return istr>>std::ws;
          default: str+=c;
        }
      }
    }
  }
  istr.setstate(std::ios::failbit);
  return istr;
}
