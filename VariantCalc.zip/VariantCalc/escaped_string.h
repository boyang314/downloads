#ifndef _ESCAPED_STRING_H_
#define _ESCAPED_STRING_H_

#include <string>
#include <iostream>

class escaped_string
{
  public:
    escaped_string(){}
    escaped_string(const std::string & _str):str(_str){}
    escaped_string(const char * _str):str(_str){}

    operator std::string() const {return str;}
    bool operator< (const escaped_string & rhs) const {return str<rhs.str;}

    std::ostream & outstream (std::ostream& ostr) const;
    std::istream & instream (std::istream& istr);

    std::string get_escaped_str() const;
    void set_escaped_str(const std::string & val);
  private:
    std::string str;

};

inline std::ostream & operator<< (std::ostream & ostr, const escaped_string & str)
{
  return str.outstream(ostr);
}

inline std::istream & operator>> (std::istream & istr, escaped_string & str)
{
  return str.instream(istr);
}

#endif
