#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <assert.h>
#include <unistd.h>

#include "calculator.h"

#include "stringnumber.h"
#include "escaped_string.h"

int main(int argc, char * argv [])
{
  CCalculator calculator;
  std::string line;

  while (std::getline(std::cin, line))
    std::cout << calculator.eval(line) << std::endl;
  std::cout << "finished" << std::endl;
}


