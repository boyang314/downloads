#include "stringnumber.h"
#include <sstream>

static long int StrToInt(const std::string & val)
{
  long int result;
  std::istringstream istr(val.c_str());
  istr >> result;
  return result;
}

static double StrToFloat(const std::string & val)
{
  double result;
  std::istringstream istr(val.c_str());
  istr >> result;
  return result;
}

static std::string IntToStr(long int val)
{
  std::ostringstream ostr;
  ostr << val;
  return ostr.str();
}

static std::string FloatToStr(double val)
{
  std::ostringstream ostr;
  ostr << val;
  return ostr.str();
}


void stringnumber::setString(const std::string & val)
{
  stringValid=true;
  stringVal=val;
  intVal = StrToInt(val);
  floatVal = StrToFloat(val);
  valType=isString;
}

void stringnumber::validateString() const
{
  if (valType==isInt)
    stringVal=IntToStr(intVal);
  else if (valType==isFloat)
    stringVal=FloatToStr(floatVal);
  stringValid=true;
}
