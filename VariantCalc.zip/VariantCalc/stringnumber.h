#ifndef _STRINGNUMBER_H_
#define _STRINGNUMBER_H_

#include <string>
#include <iostream>

class stringnumber
{
  public:
    typedef long int int_t;
    typedef double float_t;
    typedef std::string string_t;
    stringnumber() {setInt(0);}
    stringnumber(float_t val) {setFloat(val);}
    stringnumber(int_t val) {setInt(val);}
    stringnumber(string_t val) {setString(val);}
    stringnumber(bool val) {setInt(val);}
    stringnumber(const char * val) {setString(std::string(val));}

    stringnumber & operator=(const stringnumber & rhs) { if (&rhs==this) return *this;
         valType=rhs.valType; intVal=rhs.intVal; floatVal=rhs.floatVal; stringValid=rhs.stringValid; stringVal=rhs.stringVal;
         return *this;}

    stringnumber operator-() const { if (valType==isFloat)
                               return stringnumber(-getFloat());
                               return stringnumber(-getInt()); }
    stringnumber operator+(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return stringnumber(getString()+rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return stringnumber(getFloat()+rhs.getFloat());
                               return stringnumber(getInt()+rhs.getInt()); }
    stringnumber operator-(const stringnumber & rhs) const { if ((valType==isFloat) || (rhs.valType==isFloat))
                               return stringnumber(getFloat()-rhs.getFloat());
                               return stringnumber(getInt()-rhs.getInt()); }
    stringnumber operator*(const stringnumber & rhs) const { if ((valType==isFloat) || (rhs.valType==isFloat))
                               return stringnumber(getFloat()*rhs.getFloat());
                               return stringnumber(getInt()*rhs.getInt()); }
    stringnumber operator/(const stringnumber & rhs) const { if ((valType==isFloat) || (rhs.valType==isFloat))
                               return stringnumber(getFloat()/rhs.getFloat());
                               return stringnumber(getInt()/rhs.getInt()); }
    stringnumber operator%(const stringnumber & rhs) const {return stringnumber(getInt()%rhs.getInt());}

    bool operator!() const { return (int_t(getInt()==0)); }
    bool operator&&(const stringnumber & rhs) const { return (getInt()&&rhs.getInt());}
    bool operator||(const stringnumber & rhs) const { return (getInt()||rhs.getInt());}

    bool operator<=(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()<=rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()<=rhs.getFloat());
                               return (getInt()<=rhs.getInt());}
    bool operator<(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()<rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()<rhs.getFloat());
                               return (getInt()<rhs.getInt());}
    bool operator>=(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()>=rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()>=rhs.getFloat());
                               return (getInt()>=rhs.getInt());}
    bool operator>(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()>rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()>rhs.getFloat());
                               return (getInt()>rhs.getInt());}
    bool operator!=(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()!=rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()!=rhs.getFloat());
                               return (getInt()!=rhs.getInt());}
    bool operator==(const stringnumber & rhs) const {
                               if ((valType==isString) || (rhs.valType==isString))
                                 return (getString()==rhs.getString());
                               if ((valType==isFloat) || (rhs.valType==isFloat))
                                 return (getFloat()==rhs.getFloat());
                               return (getInt()==rhs.getInt());}

    std::ostream & stream_out(std::ostream& ostr) const {
                               if (valType==isString)
                                 return ostr<<stringVal;
                               if (valType==isFloat)
                                 return ostr<<floatVal;
                               return ostr<<intVal;}

    long int getInt() const {return intVal;}
    double getFloat() const {return floatVal;}
    std::string getString() const {if (!stringValid) validateString(); return stringVal;}

    void setInt(long int val) {intVal=val; floatVal=val; valType=isInt; stringValid=false;}
    void setFloat(double val) {intVal=(long int)val; floatVal=val; valType=isFloat; stringValid=false;}
    void setString(const std::string & val);

  private:
    enum {isInt, isFloat, isString} valType;
    void validateString() const;
    long int intVal;
    double floatVal;
    mutable bool stringValid;
    mutable std::string stringVal;
};

inline std::ostream & operator<<(std::ostream& ostr, const stringnumber & stn)
{
  return stn.stream_out(ostr);
}

#endif
