// � Copyright John R. Bandela 2002.

// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all
// copies. This software is provided "as is" without express or
// implied warranty, and with no claim as to its suitability for any
// purpose.

#include<exception>
#include<stdexcept>
#include<vector>
#include <string>
#include <algorithm>
#include <iostream>

	namespace spirit{
		namespace ast{
			namespace detail{




   namespace detail{
    struct deleter{
      template<class T>
      void operator()(const T* p){
         delete p;
      }
     };

     struct output_child{
      output_child(std::ostream& os):pos_(&os){}
      std::ostream* pos_;
      template<class T>
      void operator()(T* p){
         (*pos_) << *p;
      }
     };






   }
     inline std::string xml_escape(const std::string& s){
         std::string ret;
         for(std::string::const_iterator i = s.begin();i != s.end(); ++i){
            switch(*i){
               case '\"':  ret += "&quot;";break;
               case '\'':  ret += "&apos;";break;
               case '&':   ret += "&amp;";break;
               case '<':   ret += "&lt;";break;
               case '>':   ret += "&gt;";break;
               default:    ret +=*i;

            }

         }
         return ret;

     }
   inline std::string xml_begin(const std::string& s){
      return "<" + s + ">";
     }

   inline std::string xml_end(const std::string& s){
      return "</" + s + ">";
   }
class tree_node_base{

private:

   std::vector<tree_node_base*> children_;
   std::string value_;
   std::string name_;
   tree_node_base* parent_;
   void parent(tree_node_base* p){
      parent_ = p;
     }
public:
   tree_node_base():parent_(0){}
   tree_node_base(const std::string& name):name_(name),parent_(0){}
   tree_node_base(const std::string& name,const std::string& value)
      :value_(value),name_(name),parent_(0){}


   void value(const std::string& v){
      value_ = v;
   }
   const std::string& value() const{
      return value_;
   }
   void name(const std::string& n){
      name_ = n;
   }
   const std::string& name() const{
      return name_;
   }

   int children() const{
      return children_.size();
   }

   tree_node_base* parent()const {return parent_;}

   virtual ~tree_node_base(){
      std::for_each(children_.begin(),children_.end(),
         detail::deleter());

   }

   friend std::ostream& operator <<(std::ostream& os, const tree_node_base& t);
   std::string getPath(){
      std::string s;
      for(tree_node_base* p = parent();p != 0; p = p->parent()){
         s = xml_escape(p->name()) + "/" + s;
      }
      return s;
   }
protected:
   void add_child_imp(tree_node_base* node){
      children_.push_back(node);
      node->parent(this);
   }
   void add_child_imp(tree_node_base* node,int pos){
      if(pos < 0) throw std::out_of_range("add_child_imp");
      if(pos >= children())
         children_.push_back(node);
      else
         children_.insert(children_.begin()+pos,node);
      node->parent(this);
   }
   void remove_child_imp(int pos){
      tree_node_base* child = children_[(pos)];
      children_.erase(children_.begin() + pos);
      delete child;
   }
   tree_node_base* child_imp(int pos)const{
      return children_[(pos)];
   }

   virtual void do_output(std::ostream& os)const{};






};
   std::ostream& operator <<(std::ostream& os, const tree_node_base& t){


      os << xml_begin(xml_escape(t.name()));
      os << xml_escape(t.value());

      t.do_output(os);

      std::for_each(t.children_.begin(),t.children_.end(),
        detail::output_child(os));

      os << xml_end(xml_escape(t.name()));

      return os;


   }


}
template<class T>
struct tree_node : public detail::tree_node_base{
    void add_child(T* node){
     add_child_imp(node);
   }
   void add_child(T* node,int pos){
      add_child_imp(node,pos);
   }
   void remove_child(int pos){
      remove_child_imp(pos);
   }
   T* child(int pos){
      return dynamic_cast<T*>(child_imp(pos));
   }
   tree_node(){}
   tree_node(const std::string& name):tree_node_base(name){}
   tree_node(const std::string& name,const std::string& value)
      :tree_node_base(name,value){}

};



struct default_tree_node:public tree_node<default_tree_node>{
   default_tree_node(){}
   default_tree_node(const std::string& name):tree_node<default_tree_node>(name){}
   default_tree_node(const std::string& name,const std::string& value)
      :tree_node<default_tree_node>(name,value){}
};


}
}
