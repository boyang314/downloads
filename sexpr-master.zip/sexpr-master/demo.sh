#!/bin/sh
./main script < demo.sex
